from src.retriever_agent import download_presentations
from src.parser_agent import parse_presentations

def main():
    pdf_dir = "data/downloads"
    json_dir = "data/json"
    files = download_presentations(pdf_dir)
    parse_presentations(files, json_dir)

if __name__ == "__main__":
    main()
