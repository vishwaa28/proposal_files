import os, requests, re
from bs4 import BeautifulSoup

COMPANIES = {
    "TCS": "https://www.tcs.com",
    "Hexaware": "https://hexaware.com",
    "Coforge": "https://www.coforge.com",
    "Persistent": "https://www.persistent.com",
    "HCL": "https://www.hcltech.com",
}

def find_presentation_url(base_url: str):
    try:
        r = requests.get(base_url + "/investors", timeout=10)
        soup = BeautifulSoup(r.text, "html.parser")
        links = [a['href'] for a in soup.find_all('a', href=True) if re.search(r'presentation.*\.pdf', a['href'], re.I)]
        if links:
            return links[0] if links[0].startswith("http") else base_url + links[0]
    except Exception as e:
        print("Error retrieving", base_url, e)
    return None

def download_presentations(outdir):
    os.makedirs(outdir, exist_ok=True)
    files = {}
    for name, url in COMPANIES.items():
        link = find_presentation_url(url)
        if not link:
            print("No presentation for", name)
            continue
        try:
            resp = requests.get(link, timeout=15)
            fn = os.path.join(outdir, f"{name}.pdf")
            with open(fn, "wb") as f:
                f.write(resp.content)
            files[name] = fn
            print("Downloaded", name, "->", fn)
        except Exception as e:
            print("Failed to download", name, e)
    return files
