import pdfplumber, pandas as pd, os, json

def parse_pdf(pdf_path):
    data = []
    try:
        with pdfplumber.open(pdf_path) as pdf:
            for page in pdf.pages:
                tables = page.extract_tables()
                for t in tables:
                    df = pd.DataFrame(t[1:], columns=t[0])
                    data.append(df.to_dict(orient="records"))
    except Exception as e:
        print("Parse error", pdf_path, e)
    return data

def parse_presentations(files, outdir):
    os.makedirs(outdir, exist_ok=True)
    results = {}
    for company, path in files.items():
        parsed = parse_pdf(path)
        outpath = os.path.join(outdir, f"{company}.json")
        with open(outpath, "w") as f:
            json.dump(parsed, f, indent=2)
        results[company] = parsed
        print("Parsed", company, "->", outpath)
    combined = os.path.join(outdir, "combined.json")
    with open(combined, "w") as f:
        json.dump(results, f, indent=2)
    return combined
