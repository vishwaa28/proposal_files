from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import json, os

app = FastAPI()
app.mount("/static", StaticFiles(directory="web/static"), name="static")
templates = Jinja2Templates(directory="web/templates")

@app.get("/", response_class=HTMLResponse)
async def dashboard(request: Request):
    data_path = "data/json/combined.json"
    data = {}
    if os.path.exists(data_path):
        with open(data_path) as f:
            data = json.load(f)
    return templates.TemplateResponse("dashboard.html", {"request": request, "data": data})
